"""Application-compiled strategy; historical research only, no order authority."""
import json
from stratosphere.development.signals import SignalProgram

SPECIFICATION_SHA256 = 'cc236b9512a38987e1f1a9c3afc57b7742a27a156faeadb66304f2d2445e7237'
_SPECIFICATION = json.loads('{"assumptions":["Application-compiled research; no verified source conformance"],"data_requirements":{"availability":"closed_bars_only","input":"ohlcv","warmup_bars":9},"entry_rules":[{"action":"open_long","condition":{"args":[{"args":[],"op":"indicator","value":"fast"},{"args":[],"op":"indicator","value":"slow"}],"op":"crosses_above","value":null},"id":"enter_long"}],"execution_requirements":{"max_positions":1,"order_type":"market","reinforcement":false,"session_end":"hold","shorting":false},"exit_rules":[{"action":"close_long","condition":{"args":[{"args":[],"op":"indicator","value":"fast"},{"args":[],"op":"indicator","value":"slow"}],"op":"crosses_below","value":null},"id":"exit_long"}],"indicators":[{"algorithm":"sma","algorithm_version":1,"id":"fast","input":"close","period":3,"timeframe_seconds":3600},{"algorithm":"sma","algorithm_version":1,"id":"slow","input":"close","period":8,"timeframe_seconds":3600}],"instrument_constraints":{"asset_classes":["crypto_spot"],"fixed_symbols":["YAHOO:BTC-USD"],"selection":"fixed"},"market_conditions":[],"missing_data_policy":{"action":"abort","max_staleness_seconds":3600},"position_sizing":{"amount":"1","mode":"fixed_base"},"schema_version":"strategy/1","signal_timing":{"evaluate":"bar_close","precedence":"exit_before_entry","submit":"next_bar_open"},"timeframes":[3600]}')

class GeneratedStrategy(SignalProgram):
    def __init__(self):
        super().__init__(_SPECIFICATION)
