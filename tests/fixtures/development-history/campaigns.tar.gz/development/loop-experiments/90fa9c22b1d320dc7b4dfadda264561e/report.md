# Strategy-agent development

Campaign `90fa9c22b1d320dc7b4dfadda264561e` · agent owner `481789642373762035540015`
Native starts: 2 / 24. Status: no_candidate_passed_filters.

| Candidate | Round | Symbol | Interval | Base return | Stress return | State |
| --- | ---: | --- | --- | ---: | ---: | --- |
| `b859e9951b90d335215c79eca1bfe227` | 0 | BTC-USD | 1h | 0E-8 | 0E-8 | completed |

Selected candidate: none
Historical compiled code only; no MT5 execution or final approval.

Ranking covers only the frozen sampled instruments, intervals and windows.
Variants used these same results: no independent holdout or global-best claim.
Synthetic fixed-unit fills; no corporate actions, margin, funding or rollover.
Final exposure stays open and is marked at the final close.
EMA is SMA-seeded; Wilder RSI is change-seeded with flat-market value 50.
Point-in-time stock membership, delisting and survivorship bias are unverified.
Year/regime buckets describe this sample; they do not validate regimes.
Compiled code/citations do not establish faithful conversion or MT5 suitability.
No final approval, portfolio assignment or broker order was activated.

## Ranking within the declared scope

- BTC-USD 1h: best sampled candidate `b859e9951b90d335215c79eca1bfe227`; passes research filters: False
- `b859e9951b90d335215c79eca1bfe227`: stress return minus stress drawdown = 0E-8; passes research filters: False

## Candidate b859e9951b90d335215c79eca1bfe227
Window: 2025-01-01–2025-01-03 exclusive; fixed units: 1.
Market hypothesis: Declared research target, not a measured suitability claim
Compiled code: /private/var/folders/jt/8dpq58y91dq6hp_6x_9j0vkm0000gn/T/pytest-of-giovanni/pytest-11/test_capture0/development/loop-experiments/cells/b859e9951b90d335215c79eca1bfe227/strategy.py
Exact definition: /private/var/folders/jt/8dpq58y91dq6hp_6x_9j0vkm0000gn/T/pytest-of-giovanni/pytest-11/test_capture0/development/loop-experiments/cells/b859e9951b90d335215c79eca1bfe227/specification.json
Code SHA-256: `2eb5a902f1e705f667bcd11ab8f4cbfc9573a3bfe541cac6929b78843c7fd327`
Same-sample yearly equity changes: {"2025": {"observations": 48, "net_equity_change": "0"}}
Prior-20-bar direction buckets: {"insufficient_history": {"observations": 20, "net_equity_change": "0"}, "up": {"observations": 11, "net_equity_change": "0"}, "flat": {"observations": 2, "net_equity_change": "0"}, "down": {"observations": 15, "net_equity_change": "0"}}